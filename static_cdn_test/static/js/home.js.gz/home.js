$('.announcement-slider').slick({
	dots: false,
	arrows: true,
	infinite: true,
	slidesToShow: 1,
	slidesToScroll: 1,
	fade: true,
	prevArrow: $('.prev-arrow-announcement'),
	nextArrow: $('.next-arrow-announcement')
});

$('.events').slick({
	dots: false,
	arrows: true,
	infinite: true,
	slidesToShow: 1,
	slidesToScroll: 1,
	fade: true,
	prevArrow: $('.prev-arrow-events'),
	nextArrow: $('.next-arrow-events')
});
